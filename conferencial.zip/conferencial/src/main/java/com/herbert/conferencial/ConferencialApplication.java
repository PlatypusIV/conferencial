package com.herbert.conferencial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferencialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferencialApplication.class, args);
	}

}
